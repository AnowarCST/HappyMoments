<?php

$servername = "localhost";
$db_username = "ihnlbd_shahin";
$db_password = "v_(0s^UvQo,M";
$db_name = "ihnlbd_happy";

/*
$connect = mysql_connect($servername,$db_username, $db_password) or die('connect error<br>'.  mysql_error());
mysql_select_db($db_name,$connect) or die('select error <br>'.  mysql_error());

die();

*/